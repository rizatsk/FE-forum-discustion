import bgLogin from "./bg-login.jpg";
import iconApp from "./iconApp.png";

export { bgLogin, iconApp };
